module Subtraction
	def self.sub(a,b)
		a=a
		b=b
		c = a - b
        print "The Subtraction of #{a} and #{b}:- "
		puts c
	end
end
