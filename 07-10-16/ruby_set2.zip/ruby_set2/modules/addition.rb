module Addition
	def self.add(a,b)
		a=a 
		b=b
		c = a + b
		print "The Addition of #{a} and #{b}:- "
		puts c
	end
end