module Division
	def self.div(a,b)
		a=a
		b=b
		c = a / b
		print "The Division of #{a} and #{b}:- "
		puts c
	end
end