module Multiplication
	def self.mul(a,b)
		a=a
		b=b
		c = a * b
		print "The Multiplication of #{a} and #{b}:- "
		puts c
	end
end