# There are some errors in this program, make it error free and run them.

numbers = [1,2,3,4]

puts numbers.first

a = 0.5
b = 1

c = a + b

puts c

result =numbers.include?(3)

puts result