class A
	puts "Hai"
end