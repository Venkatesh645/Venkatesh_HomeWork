require 'test_helper'

class ParticipentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
